require 'byebug'
class CommentsController < ApplicationController 
    
    def index
        # debugger
        if comment_params.include?(:user_id)
            @by_user = User.find(comment_params[:user_id]).comments
            render json: @by_user
        elsif comment_params.include?(:artwork_id)
            @by_artwork =  Artwork.find(comment_params[:artwork_id]).comments
            render json: @by_artwork
        else
            @comments = Comment.all 
            render json: @comments
        end
    end
    
    def create 
        @comment = Comment.new(comment_params)
        @comment.save! 
        redirect_to comment_url(@comment)
    end

    def destroy 
        @comment = Comment.find(params[:id])
        @comment.destroy
        redirect_to comment_url(@comment.artwork_id)
    end

    private

        def comment_params 
            params.require(:comment).permit(:id, :user_id, :artwork_id, :body)
        end
end

