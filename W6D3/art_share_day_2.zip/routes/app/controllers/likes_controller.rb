require 'byebug'

class LikesController < ApplicationController
  
  def index
    debugger
    if like_params[:likeable_type] == "Artwork"
        @like = Artwork.find(like_params[:likeable_id])
    elsif like_params[:likeable_type] == "Comment"
        @like =  Comment.find(like_params[:likeable_id])
    else 
        @like = Like.all
    end
        render json: @like
  end

  def create
    @like = Like.new(like_params)
    @like.save!
    redirect_to like_url(@like)
  end

  def destroy
    @like = Like.find(params[:id])
    @like.destroy 
    redirect_to like_url(@like.likeable_id)
  end


  private
    def like_params
        params.require(:like).permit(:id, :user_id, :likeable_id, :likeable_type)
    end
end
