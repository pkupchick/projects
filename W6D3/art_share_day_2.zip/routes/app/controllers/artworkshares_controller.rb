
class ArtworksharesController < ApplicationController

    def index
        @shares = ArtworkShare.all 
        render json: @shares
    end

    def create
        @share = ArtworkShare.new(share_params)
        @share.save!
        redirect_to artworkshares_url(@share)
    end

    def destroy
        @share = ArtworkShare.find(params[:id])
        @share.destroy
        redirect_to artworkshares_url
    end

    private

        def share_params
            params.require(:artwork_share).permit(:id, :artwork_id, :artist_id)
        end

end