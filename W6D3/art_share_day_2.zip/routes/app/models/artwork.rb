# == Schema Information
#
# Table name: artworks
#
#  id         :bigint           not null, primary key
#  title      :string           not null
#  img_url    :string           not null
#  artist_id  :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Artwork < ApplicationRecord
    validates :img_url, :artist_id, :title, presence: true
    validates_uniqueness_of :title, scope: [:artist_id]

    belongs_to :artist,
        foreign_key: :artist_id,
        class_name: :User
    
    has_many :artwork_shares,
        foreign_key: :artwork_id,
        class_name: :ArtworkShare
    
    has_many :comments,
        foreign_key: :artwork_id,
        dependent: :destroy,
        class_name: :Comment

    has_many :likes, 
        as: :likeable,
        dependent: :destroy,
        class_name: :Like
end
