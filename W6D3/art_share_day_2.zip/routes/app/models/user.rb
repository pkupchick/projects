# == Schema Information
#
# Table name: users
#
#  id         :bigint           not null, primary key
#  username   :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class User < ApplicationRecord
  validates :username, presence: true
  # validates_uniqueness_of :artwork_id, scope: [:id]

  has_many :artworks,
    foreign_key: :artist_id,
    dependent: :destroy,
    class_name: :Artwork

  has_many :artwork_shares,
    foreign_key: :artist_id,
    dependent: :destroy,
    class_name: :ArtworkShare

  has_many :shared_artworks,
    through: :artwork_shares,
    dependent: :destroy,
    source: :artwork
  
  has_many :comments,
    foreign_key: :user_id, 
    dependent: :destroy,
    class_name: :Comment

  has_many :likes, 
    foreign_key: :user_id,
    dependent: :destroy,
    class_name: :Like

  has_many :liked_artworks,
      through: :artworks,
      source: :likes

  has_many :liked_comments,
    through: :comments,
    source: :likes
end
