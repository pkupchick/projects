# == Schema Information
#
# Table name: artwork_shares
#
#  id         :bigint           not null, primary key
#  artwork_id :integer          not null
#  artist_id  :integer          not null
#
class ArtworkShare < ApplicationRecord
    validates :artist_id, :artwork_id, presence: true 
    validates_uniqueness_of :artwork_id, scope: [:artist_id]

    belongs_to :artist,
        foreign_key: :artist_id,
        class_name: :User
    
    belongs_to :artwork,
        foreign_key: :artwork_id,
        class_name: :Artwork

    has_one :viewer,
        through: :artist,
        source: :artwork_shares
    
end
