# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

ActiveRecord::Base.transaction do
    User.destroy_all
    Artwork.destroy_all
    ArtworkShare.destroy_all
    Comment.destroy_all
    Like.destroy_all

    peter = User.create!(username: "pkupchick@gmail.com")
    mona = Artwork.create!(title: "Mona Lisa", img_url: "www.mona.com", artist_id: peter.id )

    rob = User.create!(username: "rob@gmail.com")
    sistine = Artwork.create!(title: "Sistine", img_url: "www.sistine.com", artist_id: rob.id )

    mitchell = User.create!(username: "mitchell@gmail.com")
    dog = Artwork.create!(title: "Dog Painting", img_url: "www.dogpainting.com", artist_id: mitchell.id )

    mildred = User.create!(username: "mildred@gmail.com")
    cat = Artwork.create!(title: "Cat Painting", img_url: "www.catpainting.com", artist_id: mildred.id )

    frank = User.create!(username: "frank@gmail.com")
    self_p = Artwork.create!(title: "Self Portrait", img_url: "www.yahoo.com", artist_id: frank.id )



    share_1 = ArtworkShare.create!(artwork_id: sistine.id, artist_id: peter.id)
    share_2 = ArtworkShare.create!(artwork_id: mona.id, artist_id: rob.id)
    share_3 = ArtworkShare.create!(artwork_id: dog.id, artist_id: peter.id)
    share_4 = ArtworkShare.create!(artwork_id: cat.id, artist_id: rob.id)
    share_5 = ArtworkShare.create!(artwork_id: self_p.id, artist_id: mildred.id)

    comment_1 = Comment.create!(user_id: peter.id, artwork_id: self_p.id, body: "Nice painting...")
    comment_2 = Comment.create!(user_id: rob.id, artwork_id: cat.id, body: "Wow you draw with your eyes closed?" )
    comment_3 = Comment.create!(user_id: mitchell.id, artwork_id: dog.id, body: "This is one killer piece of art")
    comment_4 = Comment.create!(user_id: frank.id, artwork_id: sistine.id, body: "Marvelous!")
    comment_5 = Comment.create!(user_id: mildred.id, artwork_id: mona.id, body: "That's the Mona Lisa")

    like_1 = Like.create!(user_id: peter.id, likeable_id: sistine.id, likeable_type: sistine.class.to_s)
    like_2 = Like.create!(user_id: rob.id, likeable_id: cat.id, likeable_type: cat.class.to_s)
    like_3 = Like.create!(user_id: frank.id, likeable_id: comment_4.id, likeable_type: comment_4.class.to_s)
    like_4 = Like.create!(user_id: mildred.id, likeable_id: mona.id, likeable_type: mona.class.to_s)
    like_5 = Like.create!(user_id: mitchell.id, likeable_id: self_p.id, likeable_type: self_p.class.to_s)
    like_6 = Like.create!(user_id: peter.id, likeable_id: comment_3.id, likeable_type: comment_3.class.to_s)
end