class EditLikes < ActiveRecord::Migration[5.2]
  def change
    change_column :likes, :artwork_id, :integer, null: true
    change_column :likes, :comment_id, :integer, null: true
  end
end
