class AddLikeableToLikes < ActiveRecord::Migration[5.2]
  def change
    add_column :likes, :likeable_id, :integer, null: false
    add_column :likes, :likeable_type, :string, null: false
    remove_column :likes, :artwork_id
    remove_column :likes, :comment_id
    add_index :likes, :likeable_type
    add_index :likes, :likeable_id
  end
  
end
