require "byebug"
class Item
    attr_accessor :title, :description, :deadline
    attr_reader :done
    def self.valid_date?(date_string)
        arr = date_string.split("-")
        return false if arr.length != 3 || arr[0].length != 4 
        return false if arr[1].to_i > 12 || arr[1].to_i < 1
        return false if arr[2].to_i > 31 || arr[2].to_i < 1
        true
    end

    def initialize(title, deadline, description)
        @title = title
        if Item.valid_date?(deadline)
            @deadline = deadline
        else
            raise "invalid date"
        end
        @description = description
        @done = false
    end

    def toggle
        @done = !@done
    end

    def deadline=(new_deadline)
        if Item.valid_date?(new_deadline)
            @deadline = new_deadline
        else
            raise "deadline is not valid date"
        end
    end


    
end