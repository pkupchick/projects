require "byebug"

class Code
 
  attr_reader :pegs 

  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  def self.valid_pegs?(pegs)
    pegs.all? { |peg| POSSIBLE_PEGS.keys.include?(peg.upcase) }
  end

  def initialize(pegs)
    if Code.valid_pegs?(pegs)
      @pegs = pegs.map(&:upcase)
    else
      raise "Not valid pegs"
    end
  end

  def self.random(num)
    pegs =[]
    num.times { pegs << POSSIBLE_PEGS.keys.sample }
    Code.new(pegs)
  end

  def self.from_string(peg_str) 
    Code.new(peg_str.split(""))
  end

  def [](num)
    @pegs[num]
  end

  def length
    @pegs.length
  end

  def num_exact_matches(code_instance)
    count = 0
    self.pegs.each_with_index do |peg, i|
      code_instance.pegs.each_with_index do |peg2, i2|
        if peg == peg2 && i == i2
          count += 1
        end
      end
    end
    puts count
  end


  def num_near_matches(code_instance)
    count = 0
    code_instance.pegs.each do |peg|
      if self.pegs.include?(peg)
        count += 1
      end
    end
    puts count - self.num_exact_matches(code_instance) 
  end

  def ==(code_instance)
    self.pegs == code_instance.pegs
  end

end


# code = Code.new(["R", "B", "G", "Y"])
# code.num_near_matches(Code.new(["R", "Y", "Y", "B"]))

