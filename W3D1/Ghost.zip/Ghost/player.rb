
class Player

    def initialize(name)
        @name = name
    end

    def guess
        take_turn(current_player)
    end

    
end
