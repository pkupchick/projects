def max_tie_breaker(arr, prc, &blc)
    hash = Hash.new(0)
    arr.each do |ele|
        hash[ele] = blc.call(ele)
    end
    almost = hash.sort_by {|k, v| v}
    almost[-1][0]
end

